from setuptools import setup

setup(
    name='koko-keywords',
    version='0.0.1',
    author='Kareem Kouddous',
    license='MIT',
    include_package_data = True,
    install_requires=[
        'cffi==1.15.0'
    ],
)
